﻿namespace IoCWebApp.Intefaces
{
    public interface IContactInfo
    {
        string GetInfo();
    }
}