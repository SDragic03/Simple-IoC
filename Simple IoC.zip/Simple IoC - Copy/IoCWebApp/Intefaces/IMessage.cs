﻿namespace IoCWebApp.Intefaces
{
    public interface IMessage
    {
        string GetMessage();
    }
}