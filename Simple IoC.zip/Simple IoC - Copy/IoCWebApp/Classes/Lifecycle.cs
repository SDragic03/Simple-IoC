﻿namespace IoCWebApp.Classes
{
    public enum Lifecycle
    {
        Transient, Singleton
    }
}
